package com.example.cardapioapp.productdetails

data class ProductDTO(
    val name: String,
    val price: Double,
    val quantity: Int
)
